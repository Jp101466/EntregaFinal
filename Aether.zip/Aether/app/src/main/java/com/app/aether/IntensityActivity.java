package com.app.aether;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.Random;

public class IntensityActivity extends AppCompatActivity {

    TextView valueIntensity;
    Button btn_setIntensity;
    ImageButton btn_info;
    SeekBar seekBar;
    DatabaseReference databaseReference;
    FirebaseAuth auth;
    String userId;
    Random random = new Random();
    String IntensityID = String.valueOf(random.nextInt(9000) + 1000);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_intensity);

        valueIntensity = findViewById(R.id.txt_intensityValue);
        btn_setIntensity = findViewById(R.id.btn_setIntensity);
        btn_info = findViewById(R.id.btn_intensityInfo);
        seekBar = findViewById(R.id.seekBarIntensity);

        auth = FirebaseAuth.getInstance();
        userId = auth.getCurrentUser().getUid();
        databaseReference = FirebaseDatabase.getInstance().getReference();

        seekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                valueIntensity.setText("Intensidad: " + progress);
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {
            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
            }
        });

        btn_setIntensity.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int intensityValue = seekBar.getProgress();

                databaseReference.child("Usuarios").child(userId).child("PrivateNameElec").child(IntensityID).child("PrivateIntensity").child(IntensityID).setValue(intensityValue).addOnCompleteListener(new OnCompleteListener<Void>() {
                    @Override
                    public void onComplete(@NonNull Task<Void> task) {
                        if(task.isSuccessful()) {
                            Toast.makeText(IntensityActivity.this, "Intensidad establecida", Toast.LENGTH_SHORT).show();
                            startActivity(new Intent(IntensityActivity.this, LobbyActivity.class));
                        }else {
                            Toast.makeText(IntensityActivity.this, "Error al establecer intensidad", Toast.LENGTH_SHORT).show();
                        }
                    }
                });
            }
        });

        btn_info.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mostrarDialogoInfo();
            }
        });
    }

    private void mostrarDialogoInfo() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Establecer intensidad");
        builder.setMessage("Esta función permite controlar la intensidad de flujo de corriente de un electrodoméstico mediante una barra, donde 0 es la intensidad más baja y 100 la mayor.");
        builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int id) {
                dialog.dismiss();
            }
        });
        AlertDialog dialog = builder.create();
        dialog.show();
    }
}
