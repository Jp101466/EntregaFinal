package com.app.aether;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;


import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.TimePickerDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TimePicker;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.Calendar;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.Random;

public class CrearHorarioActivity extends AppCompatActivity {

    int uniqueNotificationId = (int) System.currentTimeMillis();
    Button btn_done;
    ImageButton btn_info;
    EditText fechaInicio, fechaFin, horaInicio, horaFin;
    DatabaseReference reference;
    String userId, elecID;
    private final static String CHANNEL_ID = "NOTIFICACION";
    private final static int NOTIFICACION_ID = 0;
    Random random = new Random();
    int numeroAleatorioHorario = random.nextInt(9000) + 1000;
    FirebaseAuth auth;
    NameActivity nameActivity;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_crear_horario);
        elecID = String.valueOf(numeroAleatorioHorario);

        reference = FirebaseDatabase.getInstance().getReference();
        auth = FirebaseAuth.getInstance();
        userId = auth.getCurrentUser().getUid();
        String horarioID = String.valueOf(numeroAleatorioHorario);
        btn_done = findViewById(R.id.btn_done);
        fechaInicio = findViewById(R.id.fechaInicio);
        fechaFin = findViewById(R.id.fechaFin);
        horaInicio = findViewById(R.id.horaInicio);
        horaFin = findViewById(R.id.horaFin);
        btn_info = findViewById(R.id.btn_info);
        btn_info.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mostrarDialogoInfo();
            }
        });

        btn_done.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                createNotificationChannel();
                createNotification();

                int fechaInicioInt = convertirFecha(fechaInicio.getText().toString());
                int fechaFinInt = convertirFecha(fechaFin.getText().toString());
                int horaInicioInt = convertHora(horaInicio.getText().toString());
                int horaFinInt = convertHora(horaFin.getText().toString());

                Map<String, Object> horarioData = new HashMap<>();
                horarioData.put("fechaInicio", fechaInicioInt);
                horarioData.put("fechaFin", fechaFinInt);
                horarioData.put("horaInicio", horaInicioInt);
                horarioData.put("horaFin", horaFinInt);

                reference.child("Usuarios").child(userId).child("PrivateNameElec").child(elecID.toString()).child("PrivateHorario").child(horarioID).setValue(horarioData).addOnCompleteListener(new OnCompleteListener<Void>() {
                    @Override
                    public void onComplete(@NonNull Task<Void> task) {
                        if (task.isSuccessful()) {
                            Toast.makeText(CrearHorarioActivity.this, "Horario creado con éxito", Toast.LENGTH_SHORT).show();
                            startActivity(new Intent(CrearHorarioActivity.this, LobbyActivity.class));
                        } else {
                            Toast.makeText(CrearHorarioActivity.this, "Error al crear horario", Toast.LENGTH_SHORT).show();
                        }
                    }
                });
            }
        });
    }

    private int convertirFecha(String dateString) {
        String dateWithoutSlash = dateString.replace("/", "");
        return Integer.parseInt(dateWithoutSlash);
    }

    private int convertHora(String timeString) {
        String timeWithoutColon = timeString.replace(":", "");
        return Integer.parseInt(timeWithoutColon);
    }

    private void mostrarDialogoInfo() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Crear horario");
        builder.setMessage("Esta función permite controlar un electrodoméstico automáticamente mediante tiempos de activación y finalización. Las fechas y horas no pueden ser las mismas entre sí.");
        builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int id) {
                dialog.dismiss();
            }
        });
        AlertDialog dialog = builder.create();
        dialog.show();
    }

    private void createNotificationChannel() {
        if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            CharSequence name = "Horario creado";
            NotificationChannel notificationChannel = new NotificationChannel(CHANNEL_ID, name, NotificationManager.IMPORTANCE_DEFAULT);
            NotificationManager notificationManager = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
            notificationManager.createNotificationChannel(notificationChannel);
        }
    }
    private void createNotification() {
        NotificationCompat.Builder builder = new NotificationCompat.Builder(getApplicationContext(), CHANNEL_ID);
        builder.setSmallIcon(R.drawable.ic_logoview);
        builder.setContentTitle("Horario creado");
        builder.setContentText("Fecha de activación: " + fechaInicio.getText().toString() + "\nHora de activación: " + horaInicio.getText().toString() + "\nFecha de finalización: " + fechaFin.getText().toString() + "\nHora de finalización: " + horaFin.getText().toString());
        builder.setColor(Color.GREEN);
        builder.setPriority(NotificationCompat.PRIORITY_DEFAULT);
        builder.setLights(Color.WHITE, 1000, 1000);
        builder.setVibrate(new long[]{2000});
        builder.setDefaults(Notification.DEFAULT_SOUND);
        builder.setStyle(new NotificationCompat.BigTextStyle().bigText("Fecha de activación: " + fechaInicio.getText().toString() + "\nHora de activación: " + horaInicio.getText().toString() + "\nFecha de finalización: " + fechaFin.getText().toString() + "\nHora de finalización: " + horaFin.getText().toString()));

        NotificationManagerCompat notificationManagerCompat = NotificationManagerCompat.from(getApplicationContext());
        if (ActivityCompat.checkSelfPermission(this, android.Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            // TODO: Consider calling
            //    ActivityCompat#requestPermissions
            // here to request the missing permissions, and then overriding
            //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
            //                                          int[] grantResults)
            // to handle the case where the user grants the permission. See the documentation
            // for ActivityCompat#requestPermissions for more details.
            return;
        }
        notificationManagerCompat.notify(NOTIFICACION_ID, builder.build());
    }

    public void mostrarCalendarioInicio(View view) {

        Calendar cal = Calendar.getInstance();
        int year = cal.get(Calendar.YEAR);
        int month = cal.get(Calendar.MONTH);
        int dayOfMonth = cal.get(Calendar.DAY_OF_MONTH);

        DatePickerDialog dialog = new DatePickerDialog(CrearHorarioActivity.this, new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {
                fechaInicio.setText(dayOfMonth + "/" + (month + 1) + "/" + year);
            }
        }, year, month, dayOfMonth);

        dialog.show();
    }

    public void mostrarCalendarioFin(View view) {

        Calendar cal = Calendar.getInstance();
        int year = cal.get(Calendar.YEAR);
        int month = cal.get(Calendar.MONTH);
        int dayOfMonth = cal.get(Calendar.DAY_OF_MONTH);

        DatePickerDialog dialog = new DatePickerDialog(CrearHorarioActivity.this, new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {
                fechaFin.setText(dayOfMonth + "/" + (month + 1) + "/" + year);
            }
        }, year, month, dayOfMonth+1);

        dialog.show();
    }

    public void mostrarHorarioInicio(View view) {

        Calendar cal = Calendar.getInstance();
        int hour = cal.get(Calendar.HOUR_OF_DAY);
        int minute = cal.get(Calendar.MINUTE);

        TimePickerDialog dialog = new TimePickerDialog(CrearHorarioActivity.this, new TimePickerDialog.OnTimeSetListener() {
            @Override
            public void onTimeSet(TimePicker view, int hourOfDay, int minute) {
                String formattedTime = String.format(Locale.getDefault(), "%02d:%02d", hourOfDay, minute);
                horaInicio.setText(formattedTime);
            }
        }, hour, minute, true);
        dialog.show();
    }

    public void mostrarHorarioFin(View view) {

        Calendar cal = Calendar.getInstance();
        int hour = cal.get(Calendar.HOUR_OF_DAY);
        int minute = cal.get(Calendar.MINUTE);

        TimePickerDialog dialog = new TimePickerDialog(CrearHorarioActivity.this, new TimePickerDialog.OnTimeSetListener() {
            @Override
            public void onTimeSet(TimePicker view, int hourOfDay, int minute) {
                String formattedTime = String.format(Locale.getDefault(), "%02d:%02d", hourOfDay, minute);
                horaFin.setText(formattedTime);
            }
        }, hour, minute+1, true);
        dialog.show();
    }
}