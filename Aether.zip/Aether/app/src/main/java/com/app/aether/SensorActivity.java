package com.app.aether;


import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.ImageButton;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.Random;

public class  SensorActivity extends AppCompatActivity {

    Switch switchSensor;
    TextView statusText;
    Button btn_setSensor;
    ImageButton btn_info;
    String userId;
    DatabaseReference databaseReference = FirebaseDatabase.getInstance().getReference();
    FirebaseAuth auth = FirebaseAuth.getInstance();
    Random random = new Random();
    int switchID = random.nextInt(9000) + 1000;
    boolean switchState = false; // Variable para rastrear el estado del Switch

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sensor);

        switchSensor = findViewById(R.id.switchSensor);
        statusText = findViewById(R.id.statusText);
        btn_setSensor = findViewById(R.id.btn_setSensor);
        btn_info = findViewById(R.id.btn_sensorInfo);
        auth = FirebaseAuth.getInstance();
        userId = auth.getCurrentUser().getUid();
        databaseReference = FirebaseDatabase.getInstance().getReference();

        switchSensor.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                switchState = isChecked;
                if (isChecked) {
                    statusText.setText("Encendido");
                } else {
                    statusText.setText("Apagado");
                }
            }
        });

        btn_setSensor.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                databaseReference.child("Usuarios").child(userId).child("PrivateNameElec").child(String.valueOf(switchID)).child("PrivateSensor").child(String.valueOf(switchID)).setValue(switchState).addOnCompleteListener(new OnCompleteListener<Void>() {
                    @Override
                    public void onComplete(@NonNull Task<Void> task) {
                        if(task.isSuccessful()) {
                            Toast.makeText(SensorActivity.this, "Cambio establecido", Toast.LENGTH_SHORT).show();
                            startActivity(new Intent(SensorActivity.this, LobbyActivity.class));
                        } else {
                            Toast.makeText(SensorActivity.this, "Error al establecer el cambio", Toast.LENGTH_SHORT).show();
                        }
                    }
                });
            }
        });

        btn_info.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mostrarDialogoInfo();
            }
        });
    }

    private void mostrarDialogoInfo() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Control por sensores");
        builder.setMessage("Esta función permite controlar un electrodoméstico manualmente prendiendo y apagando el electrodoméstico mediante un Switch.");
        builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int id) {
                dialog.dismiss();
            }
        });
        AlertDialog dialog = builder.create();
        dialog.show();
    }
}

