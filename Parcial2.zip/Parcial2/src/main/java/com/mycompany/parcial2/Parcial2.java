/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.parcial2;

import com.mycompany.parcial2.View.Empleado;

/**
 *
 * @author ASUS
 */
public class Parcial2 {

    public static void main(String[] args) {
        Empleado empleado = new Empleado();
        
        empleado.setVisible(true);
        empleado.setLocationRelativeTo(null);
    }
}
