/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.parcial2.Model;

/**
 *
 * @author ASUS
 */
public class EmpleadoModel extends Persona {
    String correo;
    String contra;

    public EmpleadoModel(String correo, String contra, String Txtnombre) {
        super(Txtnombre);
        this.correo = correo;
        this.contra = contra;
    }

    @Override
    public String datos() {
        String datosEmpleado = "Nombre: " + String.valueOf(this.Txtnombre) + " Correo: " +
                String.valueOf(this.correo) + " Contraseña: " + String.valueOf(this.contra);
        return datosEmpleado;
    }
}
